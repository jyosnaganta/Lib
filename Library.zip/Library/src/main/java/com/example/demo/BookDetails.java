package com.example.demo;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
public class BookDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer book_Id;

    private String title;
    private String author;
    private String category;
    private Boolean availability = true;
	public Integer getBookId() {
		return book_Id;
	}
	public void setBookId(Integer bookId) {
		this.book_Id = bookId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Boolean getAvailability() {
		return availability;
	}
	public void setAvailability(Boolean availability) {
		this.availability = availability;
	}

    // Getters and setters
    // Constructor(s)
}
