package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

@Service
public class BookServiceDetails {
    private final BookRepositoryDetails bookRepo;

    public BookServiceDetails(BookRepositoryDetails bookRepo) {
        this.bookRepo = bookRepo;
    }

    public BookDetails addBook(BookDetails book) {
        return bookRepo.save(book);
    }

    public void removeBook(Integer bookId) {
        bookRepo.deleteById(bookId);
    }

    public List<BookDetails> searchByTitle(String title) {
        return bookRepo.findByTitleContainingIgnoreCase(title);
    }

    public List<BookDetails> searchByAuthor(String author) {
        return bookRepo.findByAuthorContainingIgnoreCase(author);
    }

    public List<BookDetails> searchByCategory(String category) {
        return bookRepo.findByCategoryContainingIgnoreCase(category);
    }
    
    // Add this method to return all books
    public List<BookDetails> getAllBooks() {
        return bookRepo.findAll();
    }

    // Add this method to update book details by id
    public BookDetails updateBook(Integer id, BookDetails updatedBook) {
        Optional<BookDetails> optionalBook = bookRepo.findById(id);
        if (optionalBook.isPresent()) {
            BookDetails existingBook = optionalBook.get();
            existingBook.setTitle(updatedBook.getTitle());
            existingBook.setAuthor(updatedBook.getAuthor());
            existingBook.setCategory(updatedBook.getCategory());
            existingBook.setAvailability(updatedBook.getAvailability());
            return bookRepo.save(existingBook);
        } else {
            throw new RuntimeException("Book not found with id " + id);
        }
    }
}

