package com.example.demo;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
public class BookControllerDetails {
    private final BookServiceDetails bookService;
    
    public BookControllerDetails(BookServiceDetails bookService) {
        this.bookService = bookService;
    }

    // Add book - POST /books
    @PostMapping
    public BookDetails addBook(@RequestBody BookDetails book) {
        return bookService.addBook(book);
    }

    // Delete book - DELETE /books/{id}
    @DeleteMapping("/{id}")
    public void removeBook(@PathVariable Integer id) {
        bookService.removeBook(id);
    }

    // Get all books - GET /books
    @GetMapping
    public List<BookDetails> getAllBooks() {
        return bookService.getAllBooks();
    }

    // Update book - PUT /books/{id}
    @PutMapping("/{id}")
    public BookDetails updateBook(@PathVariable Integer id, @RequestBody BookDetails book) {
        return bookService.updateBook(id, book);
    }

    // Search by title - GET /books/search/title?title=xyz
    @GetMapping("/search/title")
    public List<BookDetails> searchByTitle(@RequestParam String title) {
        return bookService.searchByTitle(title);
    }

    // Search by author - GET /books/search/author?author=xyz
    @GetMapping("/search/author")
    public List<BookDetails> searchByAuthor(@RequestParam String author) {
        return bookService.searchByAuthor(author);
    }

    // Search by category - GET /books/search/category?category=xyz
    @GetMapping("/search/category")
    public List<BookDetails> searchByCategory(@RequestParam String category) {
        return bookService.searchByCategory(category);
    }
}
