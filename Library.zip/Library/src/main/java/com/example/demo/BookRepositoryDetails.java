package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookRepositoryDetails extends JpaRepository<BookDetails, Integer> {
    List<BookDetails> findByTitleContainingIgnoreCase(String title);
    List<BookDetails> findByAuthorContainingIgnoreCase(String author);
    List<BookDetails> findByCategoryContainingIgnoreCase(String category);
}

